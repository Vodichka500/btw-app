--
-- PostgreSQL database dump
--

\restrict Ru308amwoGaDsJwKCuiiJtuuXHN8jDiCI8avdQLxClnXCqmhFSDCQWZlpzYZmVn

-- Dumped from database version 16.13
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CriterionType; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."CriterionType" AS ENUM (
    'YES_NO',
    'SCALE',
    'TEXT'
);


ALTER TYPE public."CriterionType" OWNER TO root;

--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'SUCCESS',
    'FAILED'
);


ALTER TYPE public."MessageStatus" OWNER TO root;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'PENDING',
    'SENT',
    'CANCELED',
    'FAILED'
);


ALTER TYPE public."ReportStatus" OWNER TO root;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: root
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'TEACHER',
    'MANAGER'
);


ALTER TYPE public."Role" OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ReportCriterion; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ReportCriterion" (
    id integer NOT NULL,
    "templateId" integer DEFAULT 1 NOT NULL,
    name text NOT NULL,
    tag text NOT NULL,
    type public."CriterionType" NOT NULL
);


ALTER TABLE public."ReportCriterion" OWNER TO root;

--
-- Name: ReportCriterion_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."ReportCriterion_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ReportCriterion_id_seq" OWNER TO root;

--
-- Name: ReportCriterion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."ReportCriterion_id_seq" OWNED BY public."ReportCriterion".id;


--
-- Name: ReportCycle; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ReportCycle" (
    id integer NOT NULL,
    "periodStart" timestamp(3) without time zone NOT NULL,
    "periodEnd" timestamp(3) without time zone NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "missingCustomers" integer[] DEFAULT ARRAY[]::integer[],
    "missingTeachers" integer[] DEFAULT ARRAY[]::integer[],
    label character varying(255)
);


ALTER TABLE public."ReportCycle" OWNER TO root;

--
-- Name: ReportCycle_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."ReportCycle_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ReportCycle_id_seq" OWNER TO root;

--
-- Name: ReportCycle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."ReportCycle_id_seq" OWNED BY public."ReportCycle".id;


--
-- Name: ReportSettings; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ReportSettings" (
    id integer DEFAULT 1 NOT NULL,
    "deadlineDays" integer DEFAULT 7 NOT NULL,
    "defaultReminderText" text DEFAULT ''::text NOT NULL
);


ALTER TABLE public."ReportSettings" OWNER TO root;

--
-- Name: ReportTemplate; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ReportTemplate" (
    id integer DEFAULT 1 NOT NULL,
    body text NOT NULL
);


ALTER TABLE public."ReportTemplate" OWNER TO root;

--
-- Name: StudentReport; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."StudentReport" (
    id integer NOT NULL,
    "cycleId" integer NOT NULL,
    "studentId" integer NOT NULL,
    "lessonsAttended" integer NOT NULL,
    "groupName" text,
    "teacherId" integer NOT NULL,
    status public."ReportStatus" DEFAULT 'PENDING'::public."ReportStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "canceledAt" timestamp(3) without time zone,
    "cancelReason" text,
    "additionalText" text,
    "generatedText" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "sendError" text,
    "templateSnapshot" jsonb
);


ALTER TABLE public."StudentReport" OWNER TO root;

--
-- Name: StudentReport_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."StudentReport_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StudentReport_id_seq" OWNER TO root;

--
-- Name: StudentReport_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."StudentReport_id_seq" OWNED BY public."StudentReport".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO root;

--
-- Name: account; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.account (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "providerId" text NOT NULL,
    "userId" text NOT NULL,
    "accessToken" text,
    "refreshToken" text,
    "idToken" text,
    "accessTokenExpiresAt" timestamp(3) without time zone,
    "refreshTokenExpiresAt" timestamp(3) without time zone,
    scope text,
    password text,
    "createdAt" timestamp(3) without time zone NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.account OWNER TO root;

--
-- Name: alfaSubjects; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."alfaSubjects" (
    id integer NOT NULL,
    alfa_id integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public."alfaSubjects" OWNER TO root;

--
-- Name: alfaSubjects_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public."alfaSubjects_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."alfaSubjects_id_seq" OWNER TO root;

--
-- Name: alfaSubjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public."alfaSubjects_id_seq" OWNED BY public."alfaSubjects".id;


--
-- Name: alfa_settings; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.alfa_settings (
    id integer NOT NULL,
    email text NOT NULL,
    "apiKey" text NOT NULL,
    token text,
    "tokenExpiresAt" timestamp(3) without time zone
);


ALTER TABLE public.alfa_settings OWNER TO root;

--
-- Name: alfa_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.alfa_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alfa_settings_id_seq OWNER TO root;

--
-- Name: alfa_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.alfa_settings_id_seq OWNED BY public.alfa_settings.id;


--
-- Name: billing_logs; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.billing_logs (
    id integer NOT NULL,
    alfa_id integer NOT NULL,
    amount_calculated double precision NOT NULL,
    message_body text NOT NULL,
    sent_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."MessageStatus" NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL
);


ALTER TABLE public.billing_logs OWNER TO root;

--
-- Name: billing_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.billing_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_logs_id_seq OWNER TO root;

--
-- Name: billing_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.billing_logs_id_seq OWNED BY public.billing_logs.id;


--
-- Name: billing_templates; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.billing_templates (
    id integer NOT NULL,
    name text NOT NULL,
    body text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.billing_templates OWNER TO root;

--
-- Name: billing_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.billing_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.billing_templates_id_seq OWNER TO root;

--
-- Name: billing_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.billing_templates_id_seq OWNED BY public.billing_templates.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "parentId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deletedAt" timestamp(3) without time zone
);


ALTER TABLE public.categories OWNER TO root;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO root;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    alfa_id integer NOT NULL,
    is_self_paid boolean DEFAULT true NOT NULL,
    student_tg_chat_id text,
    parent_tg_chat_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    name text NOT NULL,
    is_removed boolean DEFAULT false NOT NULL,
    is_study integer DEFAULT 1 NOT NULL,
    note text,
    teacher_ids integer[],
    custom_class text
);


ALTER TABLE public.customers OWNER TO root;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO root;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: message_logs; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.message_logs (
    id integer NOT NULL,
    alfa_id integer NOT NULL,
    message_body text NOT NULL,
    status public."MessageStatus" NOT NULL,
    error_reason text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.message_logs OWNER TO root;

--
-- Name: message_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.message_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.message_logs_id_seq OWNER TO root;

--
-- Name: message_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.message_logs_id_seq OWNED BY public.message_logs.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.session (
    id text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    token text NOT NULL,
    "createdAt" timestamp(3) without time zone NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "userId" text NOT NULL
);


ALTER TABLE public.session OWNER TO root;

--
-- Name: snippets; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.snippets (
    id integer NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "categoryId" integer NOT NULL,
    favorite boolean DEFAULT false NOT NULL,
    color text DEFAULT '#FFFFFF'::text,
    "order" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "deletedAt" timestamp(3) without time zone,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL
);


ALTER TABLE public.snippets OWNER TO root;

--
-- Name: snippets_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.snippets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.snippets_id_seq OWNER TO root;

--
-- Name: snippets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.snippets_id_seq OWNED BY public.snippets.id;


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    "alfacrmId" integer,
    name text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.subjects OWNER TO root;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO root;

--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: sync_states; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.sync_states (
    type text NOT NULL,
    synced_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sync_states OWNER TO root;

--
-- Name: teacher_subjects; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.teacher_subjects (
    "teacherId" integer NOT NULL,
    "subjectId" integer NOT NULL
);


ALTER TABLE public.teacher_subjects OWNER TO root;

--
-- Name: teacher_working_hours; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.teacher_working_hours (
    id integer NOT NULL,
    "teacherId" integer NOT NULL,
    "dayIndex" integer NOT NULL,
    "timeFrom" text NOT NULL,
    "timeTo" text NOT NULL
);


ALTER TABLE public.teacher_working_hours OWNER TO root;

--
-- Name: teacher_working_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.teacher_working_hours_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teacher_working_hours_id_seq OWNER TO root;

--
-- Name: teacher_working_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.teacher_working_hours_id_seq OWNED BY public.teacher_working_hours.id;


--
-- Name: teachers; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.teachers (
    id integer NOT NULL,
    "alfacrmId" integer NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    "avatarUrl" text,
    note text DEFAULT 'Заметка'::text
);


ALTER TABLE public.teachers OWNER TO root;

--
-- Name: teachers_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.teachers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.teachers_id_seq OWNER TO root;

--
-- Name: teachers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.teachers_id_seq OWNED BY public.teachers.id;


--
-- Name: telegram_sessions; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.telegram_sessions (
    id integer DEFAULT 1 NOT NULL,
    "phoneNumber" text,
    "sessionString" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.telegram_sessions OWNER TO root;

--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    id text NOT NULL,
    email text NOT NULL,
    name text,
    "emailVerified" boolean NOT NULL,
    image text,
    "createdAt" timestamp(3) without time zone NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    alfa_email text,
    alfa_token text,
    role public."Role" DEFAULT 'TEACHER'::public."Role" NOT NULL,
    tg_chat_id text,
    teacher_id integer
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: verification; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.verification (
    id text NOT NULL,
    identifier text NOT NULL,
    value text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone,
    "updatedAt" timestamp(3) without time zone
);


ALTER TABLE public.verification OWNER TO root;

--
-- Name: ReportCriterion id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportCriterion" ALTER COLUMN id SET DEFAULT nextval('public."ReportCriterion_id_seq"'::regclass);


--
-- Name: ReportCycle id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportCycle" ALTER COLUMN id SET DEFAULT nextval('public."ReportCycle_id_seq"'::regclass);


--
-- Name: StudentReport id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentReport" ALTER COLUMN id SET DEFAULT nextval('public."StudentReport_id_seq"'::regclass);


--
-- Name: alfaSubjects id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."alfaSubjects" ALTER COLUMN id SET DEFAULT nextval('public."alfaSubjects_id_seq"'::regclass);


--
-- Name: alfa_settings id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.alfa_settings ALTER COLUMN id SET DEFAULT nextval('public.alfa_settings_id_seq'::regclass);


--
-- Name: billing_logs id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billing_logs ALTER COLUMN id SET DEFAULT nextval('public.billing_logs_id_seq'::regclass);


--
-- Name: billing_templates id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billing_templates ALTER COLUMN id SET DEFAULT nextval('public.billing_templates_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: message_logs id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.message_logs ALTER COLUMN id SET DEFAULT nextval('public.message_logs_id_seq'::regclass);


--
-- Name: snippets id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.snippets ALTER COLUMN id SET DEFAULT nextval('public.snippets_id_seq'::regclass);


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Name: teacher_working_hours id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teacher_working_hours ALTER COLUMN id SET DEFAULT nextval('public.teacher_working_hours_id_seq'::regclass);


--
-- Name: teachers id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teachers ALTER COLUMN id SET DEFAULT nextval('public.teachers_id_seq'::regclass);


--
-- Data for Name: ReportCriterion; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ReportCriterion" (id, "templateId", name, tag, type) FROM stdin;
1	1	Домашнее задание	{ZD}	YES_NO
2	1	Работа на уроке	{work}	SCALE
\.


--
-- Data for Name: ReportCycle; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ReportCycle" (id, "periodStart", "periodEnd", "isArchived", "createdAt", "missingCustomers", "missingTeachers", label) FROM stdin;
16	2026-04-01 00:00:00	2026-04-20 00:00:00	f	2026-04-20 00:11:25.6	{}	{}	\N
17	2026-04-01 00:00:00	2026-04-20 00:00:00	f	2026-04-20 11:48:27.02	{}	{}	Индивы (Апрель)
\.


--
-- Data for Name: ReportSettings; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ReportSettings" (id, "deadlineDays", "defaultReminderText") FROM stdin;
1	7	Привет, {TEACHER_NAME}\nНужно заполнить отчеты за период с {PERIOD_START} по {PERIOD_END}.\nВсего к заполнению: {TOTAL_COUNT} отчетов.\nНа данный момент осталось {PENDING_COUNT} из {TOTAL_COUNT}\nПросьба заполнить и отправить до {DEADLINE}
\.


--
-- Data for Name: ReportTemplate; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ReportTemplate" (id, body) FROM stdin;
1	Добрый день,\nОтчет по работе: {STUDENT_NAME}\nПосещено занятий: {ATTENDANCE}\nОтчет за период с {PERIOD_START} по {PERIOD_END}\n---\nУченик выполнял дз: {ZD}\nУсердно работал на уроке: {work}\n
\.


--
-- Data for Name: StudentReport; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."StudentReport" (id, "cycleId", "studentId", "lessonsAttended", "groupName", "teacherId", status, "sentAt", "canceledAt", "cancelReason", "additionalText", "generatedText", "createdAt", "updatedAt", "sendError", "templateSnapshot") FROM stdin;
1344	16	206	1	Indywidualne	3	CANCELED	\N	2026-04-20 00:27:50.551	lol kek	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:27:50.553	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1464	17	461	4	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1465	17	368	1	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1466	17	586	1	Indywidualne	12	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1467	17	838	1	Indywidualne	12	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1468	17	472	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1469	17	133	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1470	17	568	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1471	17	504	4	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1472	17	556	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1473	17	648	1	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1343	16	657	1	Indywidualne	3	SENT	2026-04-20 00:28:15.297	\N	\N	Бвловался	Добрый день.\nОтчет по работе: Игорь Бондаренко\nПосещено занятий: 1\nОтчет за период с 1.04.2026 по 20.04.2026\n---\nУченик выполнял дз: Tak\nУсердно работал на уроке: 1\n\nБвловался	2026-04-20 00:11:25.645	2026-04-20 00:28:15.298	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1474	17	480	1	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1475	17	716	2	Indywidualne	29	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1476	17	588	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1477	17	62	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1478	17	38	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1479	17	54	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1480	17	368	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1481	17	480	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1482	17	61	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1483	17	844	1	Indywidualne	39	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1345	16	648	1	Indywidualne	3	FAILED	\N	\N	\N	\N	Добрый день.\nОтчет по работе: Илья Артеменко\nПосещено занятий: 1\nОтчет за период с 1.04.2026 по 20.04.2026\n---\nУченик выполнял дз: Tak\nУсердно работал на уроке: 1\n	2026-04-20 00:11:25.645	2026-04-20 01:12:26.799	Brak przypisanego konta rodzica w Telegramie. Sprawdź profil klienta.	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1375	17	979	2	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1376	17	474	2	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1377	17	772	1	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1378	17	76	1	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1379	17	844	7	Indywidualne	37	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1380	17	22	5	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1381	17	478	3	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1382	17	522	1	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1383	17	16	2	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1384	17	39	5	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1385	17	596	3	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1386	17	523	1	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1387	17	12	1	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1388	17	517	2	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1389	17	554	2	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1390	17	993	2	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1391	17	950	1	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1392	17	695	2	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1393	17	641	2	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1394	17	494	2	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1395	17	206	3	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1396	17	571	3	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1397	17	772	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1398	17	471	1	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1399	17	469	5	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1400	17	567	4	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1401	17	628	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1402	17	424	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1403	17	762	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1404	17	517	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1405	17	641	3	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1406	17	628	2	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1407	17	39	4	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1408	17	38	2	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1409	17	591	3	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1410	17	63	5	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1411	17	61	6	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1412	17	717	4	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1413	17	46	2	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1414	17	62	1	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1415	17	996	6	Indywidualne	43	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1416	17	747	3	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1417	17	733	4	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1418	17	739	3	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1419	17	740	6	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1420	17	749	2	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1421	17	12	5	Indywidualne	9	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1422	17	133	5	Indywidualne	9	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1423	17	717	6	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1424	17	571	5	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1425	17	671	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1426	17	983	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1427	17	989	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1428	17	1	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1429	17	64	4	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1430	17	616	4	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1431	17	968	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1432	17	981	2	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1433	17	790	2	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1434	17	769	1	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1435	17	844	5	Indywidualne	36	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1436	17	513	1	Indywidualne	15	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1437	17	461	5	Indywidualne	15	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1438	17	1000	3	Indywidualne	15	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1439	17	894	4	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1440	17	474	2	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1441	17	687	3	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1442	17	739	1	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1443	17	983	2	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1444	17	696	3	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1445	17	654	2	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1446	17	709	3	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1447	17	588	3	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1448	17	671	2	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1449	17	826	1	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1450	17	959	1	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1451	17	425	2	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1452	17	657	1	Indywidualne	3	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1453	17	206	1	Indywidualne	3	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1454	17	648	1	Indywidualne	3	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1455	17	930	2	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1456	17	12	4	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1457	17	769	3	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1458	17	821	1	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1459	17	616	3	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1460	17	863	3	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1461	17	769	5	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1266	16	979	2	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1267	16	474	2	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1268	16	772	1	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1269	16	76	1	Indywidualne	22	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1270	16	844	7	Indywidualne	37	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1271	16	22	5	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1272	16	478	3	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1273	16	522	1	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1274	16	16	2	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1275	16	39	5	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1276	16	596	3	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1277	16	523	1	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1278	16	12	1	Indywidualne	1	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1279	16	517	2	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1280	16	554	2	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1281	16	993	2	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1282	16	950	1	Indywidualne	31	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1283	16	695	2	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1284	16	641	2	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1285	16	494	2	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1286	16	206	3	Indywidualne	18	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1287	16	571	3	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1288	16	772	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1289	16	471	1	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1290	16	469	5	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1291	16	567	4	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1292	16	628	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1293	16	424	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1294	16	762	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1295	16	517	2	Indywidualne	8	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1296	16	641	3	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1297	16	628	2	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1298	16	39	4	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1299	16	38	2	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1300	16	591	3	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1301	16	63	5	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1302	16	61	6	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1303	16	717	4	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1304	16	46	2	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1305	16	62	1	Indywidualne	5	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1306	16	996	6	Indywidualne	43	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1307	16	747	3	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1308	16	733	4	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1309	16	739	3	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1310	16	740	6	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1311	16	749	2	Indywidualne	30	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1312	16	12	5	Indywidualne	9	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1313	16	133	5	Indywidualne	9	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1314	16	717	6	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1315	16	571	5	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1316	16	671	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1317	16	983	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1318	16	989	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1319	16	1	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1320	16	64	4	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1321	16	616	4	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1322	16	968	3	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1323	16	981	2	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1324	16	790	2	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1325	16	769	1	Indywidualne	32	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1326	16	844	5	Indywidualne	36	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1327	16	513	1	Indywidualne	15	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1328	16	461	5	Indywidualne	15	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1329	16	1000	3	Indywidualne	15	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1330	16	894	4	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1331	16	474	2	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1332	16	687	3	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1333	16	739	1	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1334	16	983	2	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1335	16	696	3	Indywidualne	26	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1336	16	654	2	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1337	16	709	3	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1338	16	588	3	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1339	16	671	2	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1340	16	826	1	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1341	16	959	1	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1342	16	425	2	Indywidualne	19	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1346	16	930	2	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1347	16	12	4	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1348	16	769	3	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1349	16	821	1	Indywidualne	38	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1350	16	616	3	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1351	16	863	3	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1352	16	769	5	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1353	16	436	4	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1354	16	494	3	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1355	16	461	4	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1356	16	368	1	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1357	16	586	1	Indywidualne	12	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1358	16	838	1	Indywidualne	12	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1359	16	472	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1360	16	133	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1361	16	568	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1362	16	504	4	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1363	16	556	3	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1364	16	648	1	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1365	16	480	1	Indywidualne	20	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1366	16	716	2	Indywidualne	29	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1367	16	588	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1368	16	62	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1369	16	38	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1370	16	54	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1371	16	368	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1372	16	480	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1373	16	61	2	Indywidualne	7	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1374	16	844	1	Indywidualne	39	PENDING	\N	\N	\N	\N	\N	2026-04-20 00:11:25.645	2026-04-20 00:11:25.645	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1462	17	436	4	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
1463	17	494	3	Indywidualne	10	PENDING	\N	\N	\N	\N	\N	2026-04-20 11:48:27.125	2026-04-20 11:48:27.125	\N	{"id": 1, "body": "Добрый день.\\nОтчет по работе: {STUDENT_NAME}\\nПосещено занятий: {ATTENDANCE}\\nОтчет за период с {PERIOD_START} по {PERIOD_END}\\n---\\nУченик выполнял дз: {ZD}\\nУсердно работал на уроке: {work}\\n", "criteria": [{"id": 1, "tag": "{ZD}", "name": "Домашнее задание", "type": "YES_NO", "templateId": 1}, {"id": 2, "tag": "{work}", "name": "Работа на уроке", "type": "SCALE", "templateId": 1}]}
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
688d2a49-38d9-4d4d-aaf0-9b238081318f	5c7b1965f974c6e169cf4316d01380a1fd64b106f89c8f1ac7c5b5a703af56b0	2026-03-11 13:13:21.662838+00	20260311131321_init	\N	\N	2026-03-11 13:13:21.432984+00	1
0fb29f1a-1572-4180-99f9-a8a01fc0aa03	772f366815e710f0ff1abd455e5ce84242304c803003e595835806571215a86f	2026-04-08 13:04:48.691009+00	20260408130448_link_billing_logs_to_customer	\N	\N	2026-04-08 13:04:48.661681+00	1
91aa87d4-3770-49aa-8dcc-a25bcbfd4865	134df0e4695c58349cf8896d4d84d9f51db03b28e4b65d0d25ae044e6bc190fb	2026-03-11 14:29:01.055174+00	20260311142900_add_auth_tables	\N	\N	2026-03-11 14:29:00.901872+00	1
de9aecdb-510f-44e7-a7a9-da5e173a8140	d2da1b5e4dc74d54079a953cf0f75e866b939a7a6f33eabf298edb6263616c75	2026-03-17 16:33:20.810534+00	20260317163320_add_roles	\N	\N	2026-03-17 16:33:20.728775+00	1
72b62033-ce3a-456c-9cb5-31f4ec6433db	0687aee62537b9d6aa73707f6909c7f7b2e550b814aca1ea4c7a190d15a46759	2026-03-24 18:42:14.098933+00	20260323151221_add_user_teacher_relation	\N	\N	2026-03-24 18:42:14.046789+00	1
8ae73c89-a2ae-4000-b311-499004e482b3	0365ea330b451c71010bd15713d45f2844d6775857e51255b6e84bde2a7583a0	2026-04-08 15:36:02.929242+00	20260408153602_add_custom_class	\N	\N	2026-04-08 15:36:02.907147+00	1
9988cc82-4921-4507-a625-33693d3c6d16	0e1d6d1a8f7facf3973aa9b9ad4961024cab8d70fd1b8cdd48b77b26e4290873	2026-03-24 18:42:15.036813+00	20260324184214_add_billing_and_clients	\N	\N	2026-03-24 18:42:14.956025+00	1
bf40a642-0ea8-42e7-9943-0618bc658d54	ca2e3e53ef093f984a14d12d291d2c448468626002a271c7a152951bb922b841	2026-03-24 18:54:45.144581+00	20260324185445_rename_client_to_customer	\N	\N	2026-03-24 18:54:45.065799+00	1
128a18a3-f7ae-43cc-b8f9-0e0cc481c4e1	0cef5e6b3bbfb0cb628e5b0f36b9f09059b064c16eafe795f2ee8862dc57097b	2026-04-20 11:42:32.712988+00	20260420114232_add_label_to_report_cycle	\N	\N	2026-04-20 11:42:32.687074+00	1
18e7be63-d8b1-43a9-bf4f-47533010e641	9d0b86126059a77bfc26f5bb113c240e3ff7e5b44ffc90c3eb56191ad8fc70b5	2026-03-24 21:16:34.889268+00	20260324211634_add_customer_name	\N	\N	2026-03-24 21:16:34.858275+00	1
1df01f67-ecae-4af8-88c6-fe5ea8559e02	b1d6c092fa317a8b2ca65f9fb011eda5aa7809325a96602acd288ca2fe91aebd	2026-04-13 10:25:23.005709+00	20260413102522_add_reports_settings	\N	\N	2026-04-13 10:25:22.88398+00	1
94339b83-2d48-487e-8c04-b24d1fc02102	6136fcd988ed5235e479d35f89341261ef36d73e10a3ae3f11001962cebf44de	2026-03-24 21:51:43.273704+00	20260324215143_add_sync_state	\N	\N	2026-03-24 21:51:43.218697+00	1
61da02c2-1dec-4517-9eb2-3ea3c580ffb4	bc570ff71812d6ad37ccd5536a07d12ccb0dd0a1b1381d585834602ad90bdb09	2026-04-07 11:34:35.222721+00	20260407113435_change_date_billing_log	\N	\N	2026-04-07 11:34:35.194169+00	1
5631c1e7-356b-4a3b-a108-a3fa882ff52a	34e72fa0aaac2a70226cbf69920242c332d3bded8546120bf9bdc730a2a21df1	2026-04-07 13:49:57.81111+00	20260407134957_add_alfa_subject_table	\N	\N	2026-04-07 13:49:57.729611+00	1
cd7947c2-c365-4455-b2fa-425dcbabaae9	73134d4621b37ae7b03b77413fbdac5116444eb2242ff803ce0e323e9cdc9545	2026-04-14 21:27:54.905201+00	20260414212754_add_reports_cycle_tables	\N	\N	2026-04-14 21:27:54.805359+00	1
6dc5f154-3a00-4437-b471-eed3806a510e	719c65af3a20c00469e41edb1089af47f22b2154bc685fb72477577e03b6d9ed	2026-04-07 20:00:02.9732+00	20260407200002_add_manager_role	\N	\N	2026-04-07 20:00:02.944202+00	1
ff9f5f3b-303b-4b34-aced-9bff411b451f	fc1cddf5f982bc4ffb0ec05360ae80925c6a0f1f842ff768f9de53d2384471db	2026-04-08 09:40:14.130959+00	20260408094014_add_telegram_session	\N	\N	2026-04-08 09:40:14.078584+00	1
c56f0573-222f-424f-b4cb-ccbb7795920a	eb091212dc78b2fd717f47af7bd1bd4d5ad0848838c3f5aa66c0ac0a6ef37875	2026-04-08 12:35:14.648769+00	20260408123307_add_fileds_to_customer_and_message_log	\N	\N	2026-04-08 12:35:14.54206+00	1
32cabdf5-b768-41c2-9154-f23ae9d8a4be	417f3d801692ce229bc7498a4cdb60c881c32aaec62b86ff981da8f7f422fd9a	2026-04-14 21:46:01.459352+00	20260414214601_add_repors_send_error	\N	\N	2026-04-14 21:46:01.430251+00	1
084b7e85-0737-4991-aad4-dff1f70697dd	3353a9604c51bab1001b19564ef0fc960290d7201d498a9358a5779e5d673c02	2026-04-20 15:55:06.95985+00	20260420155506_remove_auto_notification_table	\N	\N	2026-04-20 15:55:06.902577+00	1
4a201e10-db23-4851-af13-c13ae83b392c	ee89c4fbb82f259ac8e37ce170e0a7d97788ee5e5f42e22f62b9352a13ae54a4	2026-04-19 16:55:37.75881+00	20260419165537_remove_some_report_settings_add_missing_id_to_cycle	\N	\N	2026-04-19 16:55:37.684178+00	1
d7369236-9f3a-4910-8898-8c7a1759cee1	7d1849543f107d152c856abcdc1c63c2c935d20f87b834fe5fcdb480418d9bd4	2026-04-19 22:46:26.432086+00	20260419224626_add_template_snapshot_to_student_report	\N	\N	2026-04-19 22:46:26.405497+00	1
229e0e5e-4d9d-4561-ae22-db89638d46ca	da6ab109fce0205273ddfe6209b38d3b2359d2ab9dd97ea71e825b9d9682c642	2026-04-19 23:43:21.214267+00	20260419234321_remove_criteria_data_as_reducant_field	\N	\N	2026-04-19 23:43:21.196507+00	1
\.


--
-- Data for Name: account; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.account (id, "accountId", "providerId", "userId", "accessToken", "refreshToken", "idToken", "accessTokenExpiresAt", "refreshTokenExpiresAt", scope, password, "createdAt", "updatedAt") FROM stdin;
gjWBTL3ee4Bt6qAT1bWe8IjZtNSlmUdG	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM	credential	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM	\N	\N	\N	\N	\N	\N	90638ceaeb156cc51a8f2e7afdd7f2a4:1fde2b2cd7898f6b27256a0d7cfe6681660b11629215caabb91c95b906a93d4197e7a2ce5a2b27dd9733145770f79308e049e475b98531d4775a3ff60776da7c	2026-03-17 17:58:59.458	2026-03-17 17:58:59.458
KnNMqgmEwNlKcPEYaRXBpTHIleoXChbL	Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR	credential	Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR	\N	\N	\N	\N	\N	\N	3aa4c2b930f7c8c82f512586d93154f8:9c75764b83b28a9648b9b7c6d8183ce1dfe3482ca15acd7bc41389bac9e3220b3561ddb2a6fccb9ec0daaa81fff4977e52440465994e16805a58e4fa868755d6	2026-03-18 21:42:01.772	2026-03-18 21:42:01.772
daf8ec3b-50e2-41f2-abe8-557e04f516d1	ya.vasileuskaya@gmail.com	credential	7e24d9e3-417b-44bc-9057-6d4e2ec76e5f	\N	\N	\N	\N	\N	\N	$2b$10$j0PA9oaMXOYC0DSS5OlkhOHdcCvtUFP.0j6tlA/tRZEsJL3QBmeEq	2026-03-21 10:13:05.36	2026-03-21 10:13:05.36
\.


--
-- Data for Name: alfaSubjects; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."alfaSubjects" (id, alfa_id, name) FROM stdin;
1	18	Английский
2	14	Английский группа
3	4	Английский инд
4	15	Биология инд
5	23	Биология инд (лицей базовая)
6	25	Биология инд (лицей расширенная)
7	21	География инд
8	20	История инд
9	17	Математика
10	5	Математика группа
11	2	Математика инд
12	27	Матура математика
13	7	Польский группа
14	6	Польский инд
15	22	Польский клуб
16	16	Польский язык
17	24	Профориентация
18	19	Физика инд
19	3	Химия инд
20	26	Экзамен
\.


--
-- Data for Name: alfa_settings; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.alfa_settings (id, email, "apiKey", token, "tokenExpiresAt") FROM stdin;
3	ya.vasileuskaya@gmail.com	1817b05f-d8f0-11ef-b9b8-3cecefbdd1ae	e3bf4b2537ea966488ab5ec533d0d7f7	2026-03-11 17:04:38.262
\.


--
-- Data for Name: billing_logs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.billing_logs (id, alfa_id, amount_calculated, message_body, sent_at, status, year, month) FROM stdin;
19	717	1570	Привет, Глеб Поваляев.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Математика инд (8 занятий)\n\n- Английский инд (6 занятий)\n\n\nСумма за месяц: 1570.00 zl.	2026-04-08 20:24:43.82	SUCCESS	2026	3
20	616	1340	Привет, Андрей Слабоденюк.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Математика инд (6 занятий)\n\n- Польский инд (2 занятий)\n\n- Английский инд (3 занятий)\n\n\nСумма за месяц: 1340.00 zl.	2026-04-08 20:24:46.161	SUCCESS	2026	3
21	654	1170	Привет, Роман Клыпук.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский инд (7 занятий)\n\n- Польский инд (6 занятий)\n\n\nСумма за месяц: 1170.00 zl.	2026-04-08 20:24:48.523	SUCCESS	2026	3
22	61	1125	Привет, Леонид Васильков.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Математика инд (4 занятий)\n\n- Польский инд (6 занятий)\n\n- Английский инд (3 занятий)\n\n\nСумма за месяц: 1125.00 zl.	2026-04-08 20:24:50.987	SUCCESS	2026	3
23	717	1570	Привет, Глеб Поваляев.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Математика инд (8 занятий)\n\n- Английский инд (6 занятий)\n\n\nСумма за месяц: 1570.00 zl.	2026-04-08 20:33:57.38	SUCCESS	2026	3
24	616	1340	Привет, Андрей Слабоденюк.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Математика инд (6 занятий)\n\n- Польский инд (2 занятий)\n\n- Английский инд (3 занятий)\n\n\nСумма за месяц: 1340.00 zl.	2026-04-08 20:33:59.734	SUCCESS	2026	3
25	654	1170	Привет, Роман Клыпук.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский инд (7 занятий)\n\n- Польский инд (6 занятий)\n\n\nСумма за месяц: 1170.00 zl.	2026-04-08 20:34:02.103	SUCCESS	2026	3
26	61	1125	Привет, Леонид Васильков.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Математика инд (4 занятий)\n\n- Польский инд (6 занятий)\n\n- Английский инд (3 занятий)\n\n\nСумма за месяц: 1125.00 zl.	2026-04-08 20:34:04.547	SUCCESS	2026	3
27	996	1100	Привет, Роман Свидерский.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Польский инд (9 занятий)\n\n\nСумма за месяц: 1100.00 zl.	2026-04-08 20:34:06.929	SUCCESS	2026	3
28	671	1080	Привет, Стефания Скрипко.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский группа (7 занятий)\n\n- Польский инд (3 занятий)\n\n- Математика инд (3 занятий)\n\n\nСумма за месяц: 1080.00 zl.	2026-04-08 20:34:09.231	SUCCESS	2026	3
29	596	1062.5	Привет, Элла Тимофеева.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский группа (6 занятий)\n\n- Польский группа (6 занятий)\n\n- Математика группа (5 занятий)\n\n- Математика инд (2 занятий)\n\n\nСумма за месяц: 1062.50 zl.	2026-04-08 20:34:11.625	SUCCESS	2026	3
30	39	1050	Привет, Иван Васильков.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский инд (6 занятий)\n\n- Математика инд (5 занятий)\n\n\nСумма за месяц: 1050.00 zl.	2026-04-08 20:34:13.969	SUCCESS	2026	3
31	679	845	Привет, Владислав Рудский.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский группа (7 занятий)\n\n- Математика группа (7 занятий)\n\n- Польский группа (6 занятий)\n\n\nСумма за месяц: 845.00 zl.	2026-04-08 20:34:16.539	SUCCESS	2026	3
32	654	540	Привет, Роман Клыпук.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n\n- Английский инд (3 занятий)\n\n- Польский инд (4 занятий)\n\n\nСумма за месяц: 540.00 zl.	2026-04-20 16:33:51.459	SUCCESS	2026	3
\.


--
-- Data for Name: billing_templates; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.billing_templates (id, name, body, created_at, updated_at) FROM stdin;
1	Test	Привет, {{name}}.\n\nВ этом месяце планируются занятия по следующим предметам:\n\n{{#each subjects}}\n- {{subject_name}} ({{quantity}} занятий)\n{{/each}}\n\nСумма за месяц: {{amount}} zl.	2026-04-07 10:40:53.928	2026-04-07 10:40:53.928
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.categories (id, name, "order", "parentId", "createdAt", "deletedAt") FROM stdin;
1	test test 1	0	\N	2026-03-11 15:50:09.045	\N
2	TEst 2	1	1	2026-03-17 11:41:40.938	\N
16	Педагогам	1	\N	2026-03-21 09:34:50.809	\N
10	Телеграм	4	\N	2026-03-21 09:34:50.837	\N
8	Чистим личку	6	\N	2026-03-21 09:34:50.855	\N
3	Инстаграм	0	\N	2026-03-21 09:34:50.872	\N
4	8 класс	3	3	2026-03-21 09:34:50.923	\N
5	5-7 класс	2	3	2026-03-21 09:34:50.938	\N
6	Новый клиент/дополнения	1	3	2026-03-21 09:34:50.953	\N
7	Запись - переход в телеграм	5	3	2026-03-21 09:34:50.967	\N
9	Касания	4	3	2026-03-21 09:34:50.981	\N
11	Чистим личку	5	10	2026-03-21 09:34:50.995	\N
12	Оплата	8	10	2026-03-21 09:34:51.008	\N
13	Запись группа	6	10	2026-03-21 09:34:51.023	\N
14	Запись индив	7	10	2026-03-21 09:34:51.042	\N
15	Отчеты	9	10	2026-03-21 09:34:51.065	\N
17	На русском	3	16	2026-03-21 09:34:51.089	\N
18	На польском	2	16	2026-03-21 09:34:51.147	\N
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.customers (id, alfa_id, is_self_paid, student_tg_chat_id, parent_tg_chat_id, created_at, updated_at, name, is_removed, is_study, note, teacher_ids, custom_class) FROM stdin;
1106	479	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Адриан Попелушко	f	1	\N	{8,19}	1 курс
1107	835	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Александр Макушенко	f	1	\N	{}	5
1108	930	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алексей Ананевич	f	1	\N	{38}	8
1109	206	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алексей Гаврилов	f	1	\N	{3,18}	8
1110	959	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алексей Карташевич	f	1	\N	{}	6
1163	908	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-20 16:23:01.592	Доминика Мельянец	t	1	\N	{8}	6
1152	717	t	527330096	455565802	2026-04-08 19:50:10.935	2026-04-20 22:57:26.881	Глеб Поваляев	f	1	\N	{5,29}	8
1111	943	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алексей Кузьменко	f	1	\N	{}	8
1125	817	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-20 16:23:01.592	Анна Рабчевская	t	1	\N	{8,32,35}	8
1112	18	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алена Селищева	f	1	\N	{1}	1 курс лицей
1113	591	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алёна Харанко	f	1	\N	{5}	8
1114	695	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алеся Громыко	f	1	\N	{3,18}	8
1115	586	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алина Зембицкая	f	1	\N	{3,5}	8
1116	826	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алиса Гуцулюк	f	1	\N	{19}	6
1117	44	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Алиса Терещенко	f	1	\N	{8}	1 класс лицей
1118	527	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Альвина Евдокимова	f	1	\N	{1,8}	6
1119	391	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Анастасия Семендяева	f	1	\N	{1,5,8}	8
1120	571	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Андрей Панков	f	1	\N	{1,8,32}	8
1121	616	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Андрей Слабоденюк	f	1	\N	{3,10,18,32}	8
1122	604	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Анжелика Шеремет	f	1	\N	{1,3,10}	8
1123	602	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Анна Джуль	f	1	\N	{18,26}	8
1124	1000	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Анна Маркина	f	1	\N	{}	7
1126	71	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Аня Хилевская	f	1	\N	{8}	1 класс лицей
1127	504	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Арина Борисевич	f	1	\N	{20}	6
1128	976	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Арина Дрюк	f	1	\N	{}	\N
1129	661	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Арина Ивасенко	f	1	\N	{8}	7
1130	425	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Арина Цымбал	f	1	\N	{19}	8
1131	535	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Арина Чуйко	f	1	\N	{3,18}	8
1132	894	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Артём Рудов	f	1	\N	{26}	6
1133	812	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Артемий Садовой	f	1	\N	{1,38}	8
1134	560	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Богдан Грибко	f	1	\N	{8}	8
1135	1	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Валентин Соколовский	f	1	\N	{3,32}	8
1136	942	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Валерия Лесник	f	1	\N	{}	8
1137	104	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Валерия Лихачевская	f	1	\N	{3,20}	8
1138	579	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Валерия Совва	f	1	\N	{8}	8
1139	556	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Варвара Евич	f	1	\N	{20}	8
1140	821	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Варвара Кравцова	f	1	\N	{}	7
1141	517	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Вера Пучко	f	1	\N	{1,8}	7
1142	472	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Вероника Тарасевич	f	1	\N	{20}	6
1143	54	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Вероника Тодуа	f	1	\N	{7}	5
1144	782	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Виктория Бойко	f	1	\N	{10}	8
1145	824	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Виктория Веприцкая	f	1	\N	{5,8}	8
1146	641	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Виолетта Василькова	f	1	\N	{3,5,18}	8
1147	52	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Влад Боров	f	1	\N	{1,8}	1 класс лицей
1148	430	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Влад Кичаков	f	1	\N	{1,8}	5
1149	368	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Владислав Грачиков	f	1	\N	{7,10}	1 класс лицея
1150	679	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Владислав Рудский	f	1	\N	{5,8}	8
1151	577	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Глеб Березинский	f	1	\N	{18}	\N
1153	962	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Данил Власов	f	1	\N	{}	8
1154	971	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Данил Салеба	f	1	\N	{}	8
1155	499	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Данила Суханосик	f	1	\N	{20}	7 кл
1156	481	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Дарья Каменская	f	1	\N	{20}	8
1157	820	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Дарья Шемякова	f	1	\N	{3,32}	8
1158	733	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Даша Бурлатан	f	1	\N	{30}	8
1159	790	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Диана Галыш	f	1	\N	{32}	8
1160	522	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Диана Никитина	f	1	\N	{1}	6
1161	676	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Дима Болелов	f	1	\N	{38}	8
1162	523	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Дима Никитин	f	1	\N	{1}	3
1164	968	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Доминика Розум	f	1	\N	{}	8
1165	561	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ева Гасанова	f	1	\N	{1,3,10}	8
1166	740	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ева Кудь	f	1	\N	{30}	8
1167	486	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Евгения Яшина	f	1	\N	{1,8,10}	\N
1168	863	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Егор Мовчан	f	1	\N	{}	8
1169	570	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Екатерина Карнаухова	f	1	\N	{3,10,20}	8
1170	747	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Екатерина Хмеленко	f	1	\N	{30}	8
1171	530	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Елена Животова	f	1	\N	{1,3}	8
1172	762	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Елена Каленчиц	f	1	\N	{8}	\N
1173	614	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Захар Кулицкий	f	1	\N	{3,19}	8
1174	970	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Захар Степанюк	f	1	\N	{}	7
1175	979	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Захар Якимов	f	1	\N	{}	4 техникум
1176	663	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Злата Борова	f	1	\N	{1}	8
1177	701	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Злата Климчук	f	1	\N	{10,20}	7
1178	589	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Злата Лебедевич	f	1	\N	{8,10}	7
1179	954	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Злата Олешко	f	1	\N	{}	8
1180	39	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Иван Васильков	f	1	\N	{1,5}	8
1181	545	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Иван Горб	f	1	\N	{8}	8
1182	478	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Иван Кананчук	f	1	\N	{1}	8
1183	749	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Иван Руденко	f	1	\N	{30}	6
1184	961	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Иван Шевелёв	f	1	\N	{}	8
1185	657	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Игорь Бондаренко	f	1	\N	{1,3}	8
1186	772	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Игорь Круглов	f	1	\N	{8,22}	7
1188	732	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Илья Навицкий	f	1	\N	{28}	8
1189	712	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Илья Сторожук	f	1	\N	{1,3}	8
1190	958	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ирина Маркова	f	1	\N	{}	8
1191	838	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Кадия Маммадли	f	1	\N	{1}	8
1192	524	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Карина Слабунова	f	1	\N	{5,20}	8
1193	819	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Катя Ладутько	f	1	\N	{8}	7
1194	844	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Кирилл Индин	f	1	\N	{37}	8
1195	536	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Кирилл Пехота	f	1	\N	{10}	8
1196	12	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Костя Малый	f	1	\N	{1,8,9}	1 класс лицей
1197	787	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ксения Кебап	f	1	\N	{38}	8
1198	46	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ксения Ляпина	f	1	\N	{5}	5
1199	16	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ксения Петрова	f	1	\N	{1,5}	1 курс
1200	572	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ксения Погорелова	f	1	\N	{1}	8
1201	62	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Лев Васильков	f	1	\N	{5,7}	3
1202	494	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Лев Литвинович	f	1	\N	{10,18}	8
1203	61	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Леонид Васильков	f	1	\N	{5,7}	5
1204	578	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Лина Медведская	f	1	\N	{1}	8
1205	5	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Люба Коренькова	f	1	\N	{1,8}	1 класс лицея
1206	480	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Максим Абраменков	f	1	\N	{7,20}	8
1207	739	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Максим Белоцерковный	f	1	\N	{26,30}	6
1208	833	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Максим Галенко	f	1	\N	{1,26}	8
1209	457	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Максим Гимпель	f	1	\N	{1,8}	7
1210	461	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Максим Двирный	f	1	\N	{10,15}	2 кл техникум
1265	966	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	София Улейчик	f	1	\N	{}	5
1187	648	f	527330096	\N	2026-04-08 19:50:10.935	2026-04-20 00:31:18.434	Илья Артеменко	f	1	\N	{3,20}	8
1211	687	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Маргарита Петрова	f	1	\N	{26}	8
1212	640	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Маргарита Пивоварова	f	1	\N	{3}	8
1213	781	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Маргарита Храменкова	f	1	\N	{10}	7
1214	623	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Марина Касим	f	1	\N	{1,8}	6
1215	471	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Марина Неваленна	f	1	\N	{8}	7
1216	848	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мария Бурая	f	1	\N	{32}	8
1217	854	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мария Ковалева	f	1	\N	{}	8
1218	711	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мария Плевако	f	1	\N	{3,19}	8
1219	639	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мария Прожого	f	1	\N	{8}	8
1220	554	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мария Тихоненко	f	1	\N	{3,5,18}	8
1221	993	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мария Шелестова	f	1	\N	{}	8
1222	516	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Марк Базик	f	1	\N	{1,3,5}	8
1223	628	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Марк Грибовский	f	1	\N	{1,5,8}	6
1224	597	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Марта Щурко	f	1	\N	{1,5,8}	8
1225	22	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Матвей Бабич	f	1	\N	{1}	1 класс лицея
1226	909	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Матвей Гузенко	f	1	\N	{}	8
1227	38	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Матвей Шутиков	f	1	\N	{5,7,8}	7
1228	716	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Милана Бортник	f	1	\N	{29}	7
1229	709	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Милана Сурина	f	1	\N	{8,19}	7
1230	678	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Мирон Водолазов	f	1	\N	{5,8,18}	8
1231	708	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Михаил Осадчий	f	1	\N	{18,26}	8
1232	696	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Михаил Петров	f	1	\N	{26}	8
1233	977	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Миша Дубовик	f	1	\N	{}	5
1234	1001	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Надежда Челядинова	f	1	\N	{}	5
1235	451	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Назар Шилов	f	1	\N	{3,5}	8
1236	769	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Никита Бабец	f	1	\N	{10}	8
1237	656	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Никита Михолап	f	1	\N	{1}	8
1238	675	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Никита Подолян	f	1	\N	{5,8}	8
1239	682	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Никола Савенкова	f	1	\N	{1,10}	8
1240	133	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Николь Николаюк	f	1	\N	{15,20}	8
1241	969	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Олег Губанов	f	1	\N	{}	5
1242	892	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Оливия Розумнюк	f	1	\N	{1}	8
1243	424	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ольга Каленчиц	f	1	\N	{8}	6
1244	606	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Паулина Макаревич	f	1	\N	{1}	7
1245	705	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Платон Павленко	f	1	\N	{18}	8
1246	568	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Полина Белякова	f	1	\N	{3,20}	8
1247	952	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Полина Михаленко	f	1	\N	{}	8
1248	63	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Полина Смаль	f	1	\N	{5,8}	7
1249	754	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Полина Цалковская	f	1	\N	{28}	8
1250	757	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Полина Шовкун	f	1	\N	{38}	8
1251	436	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ратмир Луговский	f	1	\N	{10}	8
1252	837	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Роман Дятлов	f	1	\N	{26}	8
1253	654	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Роман Клыпук	f	1	\N	{19}	7
1254	996	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Роман Свидерский	f	1	\N	{}	8
1255	989	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Савва Жариков	f	1	\N	{}	1 курс
1256	492	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Саша Мельников	f	1	\N	{1}	1 кл техникума
1257	981	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Святослав Кожухарь	f	1	\N	{}	8
1258	567	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Семён Бородко	f	1	\N	{8}	8
1259	110	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Семен Лазебный	f	1	\N	{20}	7
1260	832	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Слава Михайловский	f	1	\N	{1,26,35}	8
1261	964	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	София Гошкис	f	1	\N	{}	8
1262	773	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	София Дворецкая	f	1	\N	{3,5,20}	8
1263	735	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	София Синявская	f	1	\N	{1}	6
1264	965	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	София Ступак	f	1	\N	{}	8
1266	513	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	София Фортуна	f	1	\N	{15}	1 кл лицея
1267	950	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Софья Сугако	f	1	\N	{}	8
1268	528	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Станислав Дзюбенко	f	1	\N	{19}	1 кл лицея
1269	671	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Стефания Скрипко	f	1	\N	{5,19,32}	8
1270	437	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Таисия Мазько	f	1	\N	{3,19}	7
1271	490	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Татьяна Сокол	f	1	\N	{1,28}	8
1272	893	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Тест	f	1	\N	{}	\N
1273	681	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Тимур Кашапов	f	1	\N	{1}	7
1274	64	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Фиона Скрипко	f	1	\N	{}	1 класс лицея
1275	751	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Элина Климова	f	1	\N	{10}	8
1276	596	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Элла Тимофеева	f	1	\N	{1,8,10}	8
1277	573	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Юлия Апанасевич	f	1	\N	{5,8}	8
1278	983	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Юля Неизвестная	f	1	\N	{}	8
1279	588	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ян Сержанович	f	1	\N	{3,7,19}	8
1280	624	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Яна Стефанович	f	1	\N	{1,8,10}	8
1281	474	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Яна Сянко	f	1	\N	{22,26}	5
1282	703	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ярослав Лущик	f	1	\N	{5}	8
1283	469	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ярослав Серьга	f	1	\N	{8}	8
1284	815	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ярослав Фокшаньский	f	1	\N	{18,26}	8
1285	658	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ярослав Харьков	f	1	\N	{1,5,8}	8
1286	76	f	527330096	455565802	2026-04-08 19:50:10.935	2026-04-08 20:16:51.401	Ясения Скоробогатая	f	1	\N	{9,22}	1 курс лицей
\.


--
-- Data for Name: message_logs; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.message_logs (id, alfa_id, message_body, status, error_reason, created_at) FROM stdin;
10	717	ki	SUCCESS	\N	2026-04-08 20:34:41.314
11	835	ki	SUCCESS	\N	2026-04-08 20:34:43.971
12	930	ki	SUCCESS	\N	2026-04-08 20:34:46.542
13	206	ki	SUCCESS	\N	2026-04-08 20:34:49.011
14	560	Привет	SUCCESS	\N	2026-04-20 12:23:02.12
15	206	Прив	SUCCESS	\N	2026-04-20 16:31:24.312
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.session (id, "expiresAt", token, "createdAt", "updatedAt", "ipAddress", "userAgent", "userId") FROM stdin;
s73TehQ7ig4BqGhqttWRnNEQn4XWgwJs	2026-03-24 17:58:59.475	5BBZzLxXI815kSCxgHRblQKh6fcMlz2j	2026-03-17 17:58:59.475	2026-03-17 17:58:59.475		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) @btw-app/electron/1.0.0 Chrome/142.0.7444.265 Electron/39.8.2 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
Kdt0KdrJdIc38iSfMKENeJyM94Vxxixu	2026-03-25 21:42:01.783	9q6naKqF4TVYRhimdOWpVEmjAiTHpVoD	2026-03-18 21:42:01.783	2026-03-18 21:42:01.783			Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR
wTdOFcOLhZJyRb57xmxuzp1dtxIIfVJ3	2026-03-25 21:59:07.055	kah0ApGC41E4RiuqQBXm46dYuqQcxB7s	2026-03-18 21:59:07.055	2026-03-18 21:59:07.055		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) @btw-app/electron/1.0.0 Chrome/142.0.7444.265 Electron/39.8.3 Safari/537.36	Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR
VKhgsR66wJa03OMetBzABR9waHMG0Vzu	2026-03-26 10:00:36.784	LvEMj6NIyfrwGs7vn8XlTeTPlCtPSobK	2026-03-19 10:00:36.784	2026-03-19 10:00:36.784		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) @btw-app/electron/1.0.0 Chrome/142.0.7444.265 Electron/39.8.3 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
Ne74m2QBWQLcRNHAapNjUCtYoAfGtcb6	2026-03-31 19:19:02.885	ayOlzcvWgULktaQJqgr5LPSSe7SwNlWL	2026-03-24 19:19:02.885	2026-03-24 19:19:02.885		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
30s8sT6jq3ECfXZym0WX4CcijvJtfFBj	2026-03-31 19:19:16.829	atuuh1xjiIBwNH02DehfmTBXunuMfDs1	2026-03-24 19:19:16.83	2026-03-24 19:19:16.83		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
bfuuwgpb3HBHxzbdAo5h7K81Wqlishls	2026-03-31 19:22:04.789	sBLc7nMECZSYON9Vc6auEsaLkRcD9fvP	2026-03-24 19:22:04.789	2026-03-24 19:22:04.789		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
6bmWJl6n48FEtioX6ZmrCJuxZqbX6Yew	2026-03-31 19:24:41.528	DrIeE2vTWpgZEwmPLJa0NdnpcVbB38Xq	2026-03-24 19:24:41.528	2026-03-24 19:24:41.528		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
9M7XUM4rgg7Alrt0X26aBa8GMne6Thir	2026-03-31 21:35:30.69	uQwAhuHEAUqxLfZnHBcFlqs8avcf9dbZ	2026-03-24 21:35:30.69	2026-03-24 21:35:30.69		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) BTWApp/2.0.1 Chrome/142.0.7444.265 Electron/39.8.3 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
UCD5xtUcJSSap0sdl70KpdPcoP1xO9cq	2026-04-27 23:31:53.2	3DLwqZSIbnzVGMmN6dQioZkt0tpKMdod	2026-04-19 23:30:19.428	2026-04-19 23:30:19.428		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) BTWApp/2.0.1 Chrome/142.0.7444.265 Electron/39.8.3 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
HKrZu2qLqg1y7V1i8GaRc1hlvrQMzP4X	2026-04-22 10:12:26.303	z6GVLt2ZTNIZPS9LKcEf3xmE46t5sFTD	2026-04-08 10:13:33.229	2026-04-08 10:13:33.229		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR
Q37Rf2ZqI5447nxqfbQblRol8a56dLyc	2026-04-22 10:12:40.003	LrGmjz1QTHHXOCNtB2epkzWepX0GOH2E	2026-04-15 10:12:40.004	2026-04-15 10:12:40.004		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR
TJ6TK8cgY50KJPrmywM15ujuXN3UvQO6	2026-04-22 10:13:17.171	BvdqUMBGa6R814rwNhmsBXxygMHHQhi0	2026-04-15 10:13:17.171	2026-04-15 10:13:17.171		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
zbdaCWeX9H8isnxyexhY3FHSMUjuaurB	2026-04-22 10:13:50.014	f2EOAEZhYCKSWu7mIU1ZKSBUKdFOWeH3	2026-04-15 10:13:50.014	2026-04-15 10:13:50.014		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
wAWtcpotuQcAz8FD5XS6VzjHcofb1keu	2026-04-22 10:14:34.924	MpMYGPVQdJTFLQ6fIvNavtK27RQ4T1pW	2026-04-15 10:14:34.924	2026-04-15 10:14:34.924		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
BR1erdp0xjgZzQXY6owgO2RFgOov7Ccu	2026-04-26 15:38:32.351	PzuRRE8dzv9pelkRzf3K0AcSpBenJeiH	2026-04-19 15:38:32.352	2026-04-19 15:38:32.352		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	NidgoSqisHPx84WQ2VzKu3UgClh5ROhM
sEaTYl7hDd6BgyxCxbMQa402J8EkXPDy	2026-04-26 17:49:50.706	zbuzCoWvxA7YAHNjNrBPhjZLR4ofjeDG	2026-04-19 17:49:50.706	2026-04-19 17:49:50.706		Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) BTWApp/2.0.1 Chrome/142.0.7444.265 Electron/39.8.3 Safari/537.36	Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR
\.


--
-- Data for Name: snippets; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.snippets (id, title, body, "categoryId", favorite, color, "order", "createdAt", "updatedAt", "deletedAt", variables) FROM stdin;
1	Быстрый старт	Добро пожаловать в Clippy! 🎉\n\nЭто простой текстовый сниппет.\nНажми, чтобы скопировать.\n\nПопробуй создать свои шаблоны!	1	t	#FFFFFF	0	2026-03-21 10:13:05.616	2026-03-21 10:13:05.616	\N	[]
2	Приветствие клиента	Привет, {{name}}!\n\nРады видеть тебя в {{company}}.\n\nС уважением,\n{{manager}}	2	f	#FFFFFF	0	2026-03-21 10:13:05.634	2026-03-21 10:13:05.634	\N	[]
6	Первое сообщение. Группа	Здравствуйте! 👋\nСпасибо за интерес к нашим занятиям! Сейчас у нас открыта запись в группы подготовки к экзамену восьмиклассников по трём предметам:\n\n— 📖 Польский язык\n— 📐 Математика\n— 🇬🇧 Английский язык	4	f	#FFFFFF	0	2026-03-21 10:13:05.65	2026-03-21 10:13:05.65	\N	[]
7	Второе сообщение. Группа	👥 Формат занятий:\n— Онлайн\n— Занятия проходят 2 раза в неделю по 55-60 минут\n— Мини-группы до 6 человек\n— Опытные педагоги (от 5 лет практики)\n— Упор на формат экзамена, типовые задания и развитие уверенности\n\n💬 В течение года:\n— 📊 Регулярные отчёты по каждому ребёнку\n— 📝 Минимум 2 пробных экзамена по каждому предмету\n— 🎓 Вебинар для родителей: всё о поступлении, нюансах рекрутации, сроках и требованиях	4	f	#FFFFFF	1	2026-03-21 10:13:05.664	2026-03-21 10:13:05.664	\N	[]
8	Третье сообщение. Группа	— 🧭 Дополнительно: услуги по сопровождению в поступлении в средние учебные заведения\n\n💰 Стоимость абонементов (8 занятий/месяц):\n— 1 предмет — 300 зл\n— 2 предмета — по 280 зл/каждый\n— 3 предмета — по 260 зл/каждый\n(цена за одно занятие от 32,5 до 37,5 зл)\n\n✨ Первое занятие — пробное и бесплатное\n\nХотите, запишу вас и подберем по уровню возможное расписание?\nПо каким предметам планируете готовиться? 📚🙂	4	f	#FFFFFF	2	2026-03-21 10:13:05.676	2026-03-21 10:13:05.676	\N	[]
9	Первое сообщение. Гайд	Спасибо, что подписались на нас!✨\n\nМы - онлайн-школа btw.pol 📚\nПомогаем детям адаптироваться в польской системе образования, учим математику, польский, английский, физику, химию, биологию. Готовим к экзаменам после 8 класса и к матуре, занимаемся с учениками с 4 класса и до 4-5 года лицея/техникума.\n\nЧтобы получить наш сборник «Система образования в Польше», переходите по кнопке в наш Telegram-канал там вы сможете бесплатно его скачать!	6	f	#FFFFFF	2	2026-03-21 10:13:05.69	2026-03-21 10:13:05.69	\N	[]
10	Второе сообщение. Гайд	https://t.me/btwpol/42\n\nНадеемся, наш гайд поможет вам лучше разобраться в школах Польши и выбрать правильный путь для вашего ребёнка💙	6	f	#FFFFFF	3	2026-03-21 10:13:05.703	2026-03-21 10:13:05.703	\N	[]
11	Подписчик	Добрый день! 👋\nМы — школа, которая помогает детям-эмигрантам освоиться в польской школе. Помогаем быстрее влиться в систему, понять предметы и уверенно учиться.\n\nУ нас:\n🌿 Индивидуальные и групповые занятия по ключевым предметам\n🌿 Подготовка к экзаменам 8‑классников и матуре\n\nПриглашаем в наш телеграм-канал с полезной информацией для родителей и школьников https://t.me/btwpol\n\nНапишите, пожалуйста какие занятия вас интересуют или что хотели бы узнать — с радостью подскажем! 😊\nTelegram: Contact @btwpol	6	f	#FFFFFF	1	2026-03-21 10:13:05.716	2026-03-21 10:13:05.716	\N	[]
12	Запись в группу. 8 класс	Отлично😊. \nЧтобы подобрать возможные группы по уровню, напишите пожалуйста за последние пару лет годовые оценки ребёнка (и результат пробного экзамена, если есть) по выбранным предметам и ваш никнейм в телеграмм. \nПередам информацию менеджеру, напишет вам в телеграмме и поможет подобрать подходящие группы для занятий🌿	7	f	#FFFFFF	0	2026-03-21 10:13:05.73	2026-03-21 10:13:05.73	\N	[]
13	Индив. Первое сообщение	Здравствуйте! 😊\nСпасибо за обращение! Мы проводим индивидуальные занятия по подготовке к экзамену восьмиклассников по трём предметам:\n\n— 📖 Польский язык — 100 зл/занятие\n— 📐 Математика — 95 зл/занятие\n— 🇬🇧 Английский язык — 95 зл/занятие\n\n📌 Если ребёнок занимается сразу по 3 предметам, все занятия идут по 90 зл.	4	f	#FFFFFF	3	2026-03-21 10:13:05.742	2026-03-21 10:13:05.742	\N	[]
14	Индив. Второе сообщение	Занятия проходят онлайн, в удобное для вас время.\nПреподаватель полностью ориентируется на уровень ребёнка, работает с типовыми заданиями и готовит к формату экзамена.\n\nМожно заниматься в интенсивном режиме или в более спокойном темпе — как вам комфортно.\n\n🎯 Начать можно в любое время.\n\nПробного бесплатного занятия нет, но можно оплатить одно занятие и после него принять решение о продолжении.	4	f	#FFFFFF	4	2026-03-21 10:13:05.757	2026-03-21 10:13:05.757	\N	[]
15	Индив. Третье сообщение	👋 Перед первым занятием педагог предварительно свяжется с вами: коротко созвонится, чтобы познакомиться, уточнить цели, уровень, особенности ребёнка, его мотивацию и трудности — чтобы подобрать максимально эффективный формат занятий.\n\nЕсли вам подходит, давайте подберём время на первую встречу? 🗓️	4	f	#FFFFFF	5	2026-03-21 10:13:05.772	2026-03-21 10:13:05.772	\N	[]
16	Первое сообщение. Индив	Здравствуйте! 🌿\n\nКонечно, расскажу про индивидуальные занятия.\nОни проходят онлайн в удобное для вас время, продолжительность — 55–60 минут.\nПодходят как для регулярной поддержки по школьной программе, так и для подготовки к экзаменам восьмиклассников.\n\nСтоимость индивидуальных занятий:\n▫️ Математика — 95 зл/занятие\n▫️ Польский язык — 100 зл/занятие\n▫️ Английский язык — 95 зл/занятие\n▫️ Биология, физика, химия, география, история — 95 зл/занятие	5	f	#FFFFFF	2	2026-03-21 10:13:05.787	2026-03-21 10:13:05.787	\N	[]
17	Первое сообщение. Группы	Здравствуйте! 😊\nСпасибо за ваш интерес! Мы проводим онлайн-занятия по польскому, математике и английскому для детей 5–8 классов в группах.\n\n📚 С 5 класса начинаем готовить по школьной программе CKE.\nУже с 5 класса занятия проходят с акцентом на формат контрольных и тестов, чтобы ребёнок постепенно привыкал к требованиям экзамена восьмиклассника.\n\n👩‍🏫 Уроки проходят в мини-группах до 6 человек, 2 раза в неделю по 55-60 минут.\nНаши педагоги работают по программе CKE:	5	f	#FFFFFF	0	2026-03-21 10:13:05.802	2026-03-21 10:13:05.802	\N	[]
18	Второе сообщение. Группы	— все задания и терминология предметов — на польском языке. Английский и польский языки на этих же языках и проводят, если уровень в группе позволяет.\n— объяснение — на русском, чтобы ребёнку было понятно и комфортно\n— тренируемся на типовых заданиях, готовимся к контрольным, учим применять знания в школе\n\n💰 Стоимость абонемента (8 занятий в месяц):\n▫️ 1 предмет — 300 зл\n▫️ 2 предмета — по 280 зл\n▫️ 3 предмета — по 260 зл\n\n✨ Первое занятие — пробное и бесплатное.\nХотели бы записаться на пробное занятие?	5	f	#FFFFFF	1	2026-03-21 10:13:05.816	2026-03-21 10:13:05.816	\N	[]
19	Второе сообщение. Индив	Подскажите, пожалуйста, по каким предметам нужна помощь и сколько раз в неделю планируете заниматься — подберу свободные слоты у педагогов. ✨	5	f	#FFFFFF	3	2026-03-21 10:13:05.83	2026-03-21 10:13:05.83	\N	[]
20	Запись. Индив	Отлично😊. \nНапишите пожалуйста ваше имя и ваш никнейм в телеграмм. \nПередам информацию менеджеру, напишет вам в телеграмме и поможет подобрать подходящее время для первого занятия и педагога🌿	5	f	#FFFFFF	0	2026-03-21 10:13:05.845	2026-03-21 10:13:05.845	\N	[]
21	Запись. Индив	Отлично😊. \nНапишите пожалуйста ваше имя и ваш никнейм в телеграмм. \nПередам информацию менеджеру, напишет вам в телеграмме и поможет подобрать подходящее время для первого занятия и педагога🌿	7	f	#FFFFFF	0	2026-03-21 10:13:05.861	2026-03-21 10:13:05.861	\N	[]
22	Группа. Первое касание (через 1 день)	Здравствуйте! 🌿\n\nРанее мы отправляли вам информацию о наших занятиях. Удалось ли ознакомиться и обсудить, планируете ли присоединиться?\n\nСейчас продолжаем набор в действующие и новые группы — можно выбрать удобное время и формат занятий.\n\nЕсли актуально, напишите, пожалуйста, чтобы мы забронировали место и пригласили на пробное занятие. 😊\nХотели бы записаться?	9	f	#FFFFFF	1	2026-03-21 10:13:05.876	2026-03-21 10:13:05.876	\N	[]
23	Индив. Первое касание (через 1 день)	Здравствуйте! 🌿\n\nРанее мы отправляли вам информацию о занятиях в нашем центре. Подскажите, удалось ли ознакомиться и обсудить возможные дни для занятий?\n\nХотели бы подобрать время для первого занятия?😊	9	f	#FFFFFF	2	2026-03-21 10:13:05.888	2026-03-21 10:13:05.888	\N	[]
24	Инд+группа. Первое касание (через 1 день)	Здравствуйте! 🌿\n\nРанее мы отправляли вам информацию о форматах занятий в нашем центре — индивидуальных и групповых. Подскажите, удалось ли ознакомиться и обсудить, какой формат был бы для вас предпочтительнее?\n\nСейчас продолжаем набор в действующие и новые группы — можно выбрать удобное время и формат занятий.\n\nЕсли актуально, напишите, пожалуйста, чтобы мы забронировали место и пригласили на пробное занятие. 😊\n\nЕсли всё же склоняетесь к индивидуальному формату — тоже можно согласовать удобное время и начать занятия в ближайшие дни.\n\nХотели бы запланировать и подобрать время для первого занятия? 😊	9	f	#FFFFFF	3	2026-03-21 10:13:05.9	2026-03-21 10:13:05.9	\N	[]
25	Второе касание (еще через 2 дня)	Здравствуйте! 🌿\n\nПишу, чтобы уточнить, актуален ли ещё ваш интерес к нашим занятиям.\n\nРанее мы отправляли информацию — возможно, планы изменились или остались вопросы.\n\nЕсли пока не планируете занятия, просто дайте знать, чтобы мы понимали, закрыть ли переписку.\n\nЕсли рассматриваете — с радостью подберём удобный вариант.\n\nБольше не побеспокою 🌸\n\nБудем рады видеть вас и вашего ребёнка, когда решите начать! ✨	9	f	#FFFFFF	4	2026-03-21 10:13:05.914	2026-03-21 10:13:05.914	\N	[]
66	Я	Добрый день! Меня зовут Яна, я менеджер школы BTW🤍	13	f	#FFFFFF	0	2026-03-21 10:13:06.419	2026-03-21 10:13:06.419	\N	[]
26	Отказ 1	Спасибо, что сообщили 🙏 Если можно, 1–2 фразы обратной связи: что стало решающим — расписание, формат, цена или что-то другое? Это очень помогает нам становиться лучше.\n\nВ благодарность пришлю маленький подарок  - Гайд по образованию в Польше 🌿	9	f	#FFFFFF	5	2026-03-21 10:13:05.928	2026-03-21 10:13:05.928	\N	[]
27	Отказ 2	Ссылка на гайд - https://t.me/btwpol/42	9	f	#FFFFFF	6	2026-03-21 10:13:05.939	2026-03-21 10:13:05.939	\N	[]
28	Правила	Клиент не ответил сразу/ ушел подумать после информации о занятиях\n\n1. Повторное (Первое) касание через 1 день.\n2. Если не было снова ответа: Ещё одно (Второе) через 2 дня.\n3. Поставить задачу проверить ответ через 2-3 дня:\n- Если нет ответа - закрыть заявку в CRM и пометить причину (там есть не ответа) или если ответили -выбрать причину из имеющихся\n- Если ответ есть и он отрицательный - нет, спасибо/ пока не будем и другие не конкретные формулировки, отправляем уточняющий скрипт (Отказ)	9	f	#F21818	0	2026-03-21 10:13:05.951	2026-03-21 10:13:05.951	\N	[]
29	Правила 1	1. ОБЩИЕ ПРИНЦИПЫ\n\n- ⌚ Ответ на заявки: не позднее, чем через 30-60 минут в рабочее время (08:00 – 19:00).\n- 📅 Повторные касания: 2 попытки с перерывом 1-2 дня. Если клиент не ответил на 3 касания — заявка закрывается.\n- 🪜 Стиль общения: живой, дружелюбный, но с четкой целью довести до пробного и покупки.\n\n2. Каналы поступления заявок\n\n- Instagram (Direct, комментарии)\n- Telegram (через тап-линк)\n- WhatsApp (реже, пока доступ только у Анны)\n- Повторные заявки от текущих клиентов\n\n3. Внесение в CRM (AlfaCRM)\n\nДелается после первого ответа, чтобы заявка не пропала.\n\nВносим:\n\n- Имя родителя\n- Ссылка на Instagram\n- Имя родителя (заказчик)\n- Класс\n- Запрос (что ищут)\n- Оценки за 1-2 года\n- Ник Telegram-а\n- Этапв црм: установлен конлакт/принимает решение/пробное и так далее	3	f	#F21818	0	2026-03-21 10:13:05.962	2026-03-21 10:13:05.962	\N	[]
30	Правила 2	Алгоритм обработки заявки\n\n🎨 Сценарий 1. Входящее сообщение\n\n1. Ответить в течение 30-60 минут. \n\nАвтоответы в инстаграм в зависимости от запроса (рассказываю в видео какими пользоваться в каких случаях):\nсохраненные ответы:\nhttps://youtu.be/zS_jhd0jooE часть 1\n\nhttps://youtu.be/EbxW0Px5vcE - часть 2\n\nhttps://youtu.be/9jF_qY3n21Q как адаптировать ответ под запрос\n\n2. Спросить: предмет, класс, формат (групповые/индивидуальные) - если сами не указали\n\n3. Предложить бесплатное пробное занятие, попросить оценки и ник Telegram.\n4. Перевести общение в Telegram.\n5. Завести заявку в CRM.\n \nСценарий 2. Клиент не ответил сразу/ ушел подумать после информации о занятиях:\n\nсмотри правила в касания	3	f	#F21818	1	2026-03-21 10:13:05.976	2026-03-21 10:13:05.976	\N	[]
31	Приветствие	Добрый день! 👋\nМы — школа, которая помогает детям-эмигрантам освоиться в польской школе. Помогаем быстрее влиться в систему, понять предметы и уверенно учиться.\n\nУ нас:\n🌿 Индивидуальные и групповые занятия по ключевым предметам\n🌿 Подготовка к экзаменам 8‑классников и матуре \n\nНапишите, пожалуйста какие занятия вас интересуют и в каком классе ребенок😊	6	f	#FFFFFF	0	2026-03-21 10:13:05.989	2026-03-21 10:13:05.989	\N	[]
32	Платежные данные	Для оформления оплаты занятий в бухгалтерии мне понадобятся следующие данные:\n\n- Имя и фамилия плательщика латиницей, как в паспорте\n- Адрес проживания с индексом\n\nПожалуйста, пришлите их🤍	12	f	#FFFFFF	0	2026-03-21 10:13:06.001	2026-03-21 10:13:06.001	\N	[]
33	Счет для оплаты	Счет для оплаты - Numer konta\n34114010100000543359003751\n\nИмя получателя Hanna Shautsova\nВАЖНО! Название перевода przelew указывать - nauczanie и имя фамилия ребенка❗️\n\nКак оплатите, пришлите, пожалуйста, подтверждение❤️	12	f	#FFFFFF	2	2026-03-21 10:13:06.015	2026-03-21 10:13:06.015	\N	[]
34	Напоминалка	Добрый день! Напоминаю об оплате занятий☺️\n\nЕсли вы уже оплатили, пожалуйста, пришлите подтверждение оплаты🌿	12	f	#FFFFFF	3	2026-03-21 10:13:06.028	2026-03-21 10:13:06.028	\N	[]
35	Напоминалка 2	Добрый день, вчера был последний день для оплаты занятий. Внесите, пожалуйста, сегодня оплату	12	f	#FFFFFF	4	2026-03-21 10:13:06.041	2026-03-21 10:13:06.041	\N	[]
36	.	Добрый день! Благодарю🤍	11	f	#FFFFFF	2	2026-03-21 10:13:06.055	2026-03-21 10:13:06.055	\N	[]
37	.	И вам большое спасибо🤍	11	f	#FFFFFF	3	2026-03-21 10:13:06.067	2026-03-21 10:13:06.067	\N	[]
38	.	Пришлите, пожалуйста, подтверждение оплаты☺️	11	f	#FFFFFF	4	2026-03-21 10:13:06.079	2026-03-21 10:13:06.079	\N	[]
39	Телеграм канал	📣 Присоединяйтесь к нашему Telegram-каналу!\nЗдесь вы найдёте:\n✨ Все новости школы\n🎉 Бесплатные мероприятия для детей\n👨‍👩‍👧‍👦 Анонсы новых групп\n🧠 Встречи с психологами\n...и многое другое!\n\n❗️ Вступить в канал (https://t.me/+JM0s-bcLhAM4MmU0)	14	f	#FFFFFF	6	2026-03-21 10:13:06.092	2026-03-21 10:13:06.092	\N	[]
67	Звонок	Напоминание о созвоне с мамой, время необходимо согласовать в чате☺️	17	f	#FFFFFF	0	2026-03-21 10:13:06.432	2026-03-21 10:13:06.432	\N	[]
68	Rozmowa telef.	Przypomnienie o rozmowie telefonicznej z mamą, termin należy ustalić na czacie☺️	18	f	#FFFFFF	0	2026-03-21 10:13:06.443	2026-03-21 10:13:06.443	\N	[]
40	Телеграм канал	📣 Присоединяйтесь к нашему Telegram-каналу!\nЗдесь вы найдёте:\n✨ Все новости школы\n🎉 Бесплатные мероприятия для детей\n👨‍👩‍👧‍👦 Анонсы новых групп\n🧠 Встречи с психологами\n...и многое другое!\n\n❗️ Вступить в канал (https://t.me/+JM0s-bcLhAM4MmU0)	13	f	#FFFFFF	11	2026-03-21 10:13:06.105	2026-03-21 10:13:06.105	\N	[]
41	Правила школы	Перед оформлением оплаты, пожалуйста, ознакомьтесь и подпишите правила нашей школы, напишите, как будет готово🫶\n\n\nhttps://docs.google.com/forms/d/e/1FAIpQLScFhnB0cNZB-5JUwh8VrMv0Z2djrh7nyKL5TmiD3eodWr13-Q/viewform?usp=dialog	13	f	#FFFFFF	10	2026-03-21 10:13:06.118	2026-03-21 10:13:06.118	\N	[]
42	Правила индив	Перед оформлением оплаты, пожалуйста, ознакомьтесь и подпишите правила нашей школы, напишите, как будет готово🫶\n\nhttps://docs.google.com/forms/d/e/1FAIpQLScFhnB0cNZB-5JUwh8VrMv0Z2djrh7nyKL5TmiD3eodWr13-Q/viewform?usp=dialog	14	f	#FFFFFF	4	2026-03-21 10:13:06.13	2026-03-21 10:13:06.13	\N	[]
43	1	Добрый день!🌿\nХотели бы получать регулярные комментарии об успеваемости на занятиях? ☺️	15	f	#FFFFFF	0	2026-03-21 10:13:06.144	2026-03-21 10:13:06.144	\N	[]
44	2	Для этого нужно задать никнейм @ в настройках телеграма. С помощью него мы бы присылали вам отчёты о успеваемости вашего ребенка😌\n\nСтрочку для задачи никнейма можно найти в настройках под номером телефона 🙂	15	f	#FFFFFF	1	2026-03-21 10:13:06.157	2026-03-21 10:13:06.157	\N	[]
45	Уровень	Добрый день! Чтобы подобрать возможные группы по уровню, подскажите, пожалуйста, за последние пару лет годовые оценки, и, может быть ребенок писал пробный экзамен и вы могли бы поделиться результатом?🌿	13	f	#FFFFFF	1	2026-03-21 10:13:06.169	2026-03-21 10:13:06.169	\N	[]
46	Предложение	Исходя из результата, могу вам предложить группу с расписанием:\n\n\n\nВ любом случае, первое занятие будет пробное и бесплатное, если вы поймете, что уровень вам не подходит, я смогу предложить вам еще варианты🤍\n\nХотели бы прийти на пробное занятие?🫶	13	f	#FFFFFF	2	2026-03-21 10:13:06.181	2026-03-21 10:13:06.181	\N	[]
47	Стоимость	💰 Стоимость абонементов (8 занятий/месяц):\n— 1 предмет — 300 зл\n— 2 предмета — по 280 зл/каждый\n— 3 предмета — по 260 зл/каждый\n(цена за одно занятие от 32,5 до 37,5 зл)	13	f	#FFFFFF	3	2026-03-21 10:13:06.193	2026-03-21 10:13:06.193	\N	[]
48	Инфо по ребенку	Напишите, пожалуйста, имя и фамилию ребенка, а так же ник в телеграм, чтобы я добавила его в чат с преподавателем🌿	13	f	#FFFFFF	4	2026-03-21 10:13:06.206	2026-03-21 10:13:06.206	\N	[]
49	Вступление	Отправила {{name}} ссылку на чат с преподавателем, попросите, пожалуйста, вступить😊	13	f	#FFFFFF	5	2026-03-21 10:13:06.218	2026-03-21 10:13:06.218	\N	[]
50	Слоты	Напишите, пожалуйста, все возможные варианты дней и времени, чтобы я смогла быстрее подобрать педагога🤍	14	f	#FFFFFF	0	2026-03-21 10:13:06.231	2026-03-21 10:13:06.231	\N	[]
51	Инфа по ребенку	Напишите, пожалуйста, имя и фамилию ребенка, а так же ник в телеграм, чтобы я добавила его в чат с преподавателем🌿	14	f	#FFFFFF	1	2026-03-21 10:13:06.243	2026-03-21 10:13:06.243	\N	[]
52	ДЗ	воствмовтмовомт	12	f	#000000	0	2026-03-21 10:13:06.255	2026-03-21 10:13:06.255	\N	[]
53	мамкм	мамамам\n{{name}}	11	f	#FFFFFF	0	2026-03-21 10:13:06.268	2026-03-21 10:13:06.268	\N	[]
54	ДЗ	амамаиа	15	f	#000000	0	2026-03-21 10:13:06.279	2026-03-21 10:13:06.279	\N	[]
55	аа	Привет, {{name}}	12	f	#FFFFFF	0	2026-03-21 10:13:06.29	2026-03-21 10:13:06.29	\N	[]
56	ДЗ	аааа	15	f	#B3F9F8	0	2026-03-21 10:13:06.302	2026-03-21 10:13:06.302	\N	[]
57	ааа	Привет, {{name}}	15	f	#D4DEF2	0	2026-03-21 10:13:06.313	2026-03-21 10:13:06.313	\N	[]
58	Как прошло?	Добрый день! 🌸\nКак {{name}} вчерашнее занятие? ☺️\nВсе ли понравилось? Планируете ли продолжать?🌿	13	f	#FFFFFF	8	2026-03-21 10:13:06.326	2026-03-21 10:13:06.326	\N	[]
59	Как прошло?	Добрый день! 🌸\nКак {{name}} вчерашнее занятие? ☺️\nВсе ли понравилось? Планируете ли продолжать?🌿	14	f	#FFFFFF	2	2026-03-21 10:13:06.337	2026-03-21 10:13:06.337	\N	[]
60	Стоимость	В {{month}} планируется еще {{classes}} занятия, к оплате будет {{price}} зл🫶	12	f	#FFFFFF	1	2026-03-21 10:13:06.348	2026-03-21 10:13:06.348	\N	[]
61	Дз	аоастасоуаоушу {{name}}	12	f	#000000	0	2026-03-21 10:13:06.36	2026-03-21 10:13:06.36	\N	[]
62	Инфа для родителя	Добавила {{name}} в чат, присылаю вам важную информацию:	13	f	#FFFFFF	6	2026-03-21 10:13:06.372	2026-03-21 10:13:06.372	\N	[]
63	Оплата	К оплате — {{zl}} зл 🌸\n\n✨ Важно!\nЖелательно внести оплату за 3 дня до занятия.\nЭто позволит преподавателю заранее связаться с вами, провести созвон и адаптировать первый урок под ваши цели, чтобы он прошёл максимально эффективно 💬\n\nОкончательный дедлайн оплаты — за 1 сутки до занятия.\nПри отсутствии оплаты в указанный срок занятие, к сожалению, будет отменено.\n\nЧат с преподавателем создаётся после подтверждения оплаты 🌿\n\nВ дальнейшем оплату необходимо вносить до 10 числа каждого месяца.\nОплата засчитывается только при наличии подтверждения 🤍\n\nБлагодарим за понимание ✨	14	f	#FFFFFF	5	2026-03-21 10:13:06.384	2026-03-21 10:13:06.384	\N	[]
64	.	Благодарю🤍	11	f	#FFFFFF	1	2026-03-21 10:13:06.396	2026-03-21 10:13:06.396	\N	[]
65	.	Добрый день! Меня зовут Яна, я менеджер школы BTW🤍	11	f	#FFFFFF	0	2026-03-21 10:13:06.408	2026-03-21 10:13:06.408	\N	[]
69	.	Желаю чудесных занятий🤍	13	f	#FFFFFF	7	2026-03-21 10:13:06.456	2026-03-21 10:13:06.456	\N	[]
70	.	Добрый день! Огромное вам спасибо за теплые слова❤️\nОбязательно передам педагогу🫶🥹	11	f	#FFFFFF	5	2026-03-21 10:13:06.469	2026-03-21 10:13:06.469	\N	[]
71	.	Добрый день! Рады слышать🤍	14	f	#FFFFFF	3	2026-03-21 10:13:06.481	2026-03-21 10:13:06.481	\N	[]
72	.	Добрый день! Рады слышать🤍	13	f	#FFFFFF	9	2026-03-21 10:13:06.494	2026-03-21 10:13:06.494	\N	[]
73	.	Добрый день! \nБлагодарим, что дали знать 🤍\nЕсли в будущем занятия снова будут для вас актуальны — обязательно пишите. С радостью будем ждать вас на наших занятиях 🫶	9	f	#FFFFFF	7	2026-03-21 10:13:06.507	2026-03-21 10:13:06.507	\N	[]
74	Школа	Мы - онлайн-школа btw.pol 📚\nПомогаем детям адаптироваться в польской системе образования, учим математику, польский, английский, физику, химию, биологию. Готовим к экзаменам после 8 класса и к матуре, занимаемся с учениками с 4 класса и до 4-5 года лицея/техникума.\n\nЧтобы получить наш сборник «Система образования в Польше», переходите по кнопке в наш Telegram-канал там вы сможете бесплатно его скачать!\n\nhttps://t.me/btwpol/42\n\nНадеемся, наш гайд поможет вам лучше разобраться в школах Польши и выбрать правильный путь для вашего ребёнка💙	6	f	#FFFFFF	4	2026-03-21 10:13:06.519	2026-03-21 10:13:06.519	\N	[]
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.subjects (id, "alfacrmId", name, "order") FROM stdin;
1	\N	Математика	0
2	\N	Польский язык	0
3	\N	Английский язык	0
4	\N	Химия	0
5	\N	Физика	0
6	\N	Биология/география/история	0
\.


--
-- Data for Name: sync_states; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.sync_states (type, synced_at) FROM stdin;
SUBJECTS	2026-04-07 14:14:44.646
CUSTOMERS	2026-04-20 16:23:01.618
\.


--
-- Data for Name: teacher_subjects; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.teacher_subjects ("teacherId", "subjectId") FROM stdin;
1	2
2	2
3	1
4	2
5	2
6	3
7	4
8	1
11	1
11	4
12	1
13	1
13	4
15	2
16	6
17	2
17	3
18	2
18	3
20	2
21	1
22	1
23	2
23	3
24	5
26	1
27	3
\.


--
-- Data for Name: teacher_working_hours; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.teacher_working_hours (id, "teacherId", "dayIndex", "timeFrom", "timeTo") FROM stdin;
\.


--
-- Data for Name: teachers; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.teachers (id, "alfacrmId", name, email, phone, "avatarUrl", note) FROM stdin;
2	3	Anna Kleina	kleina.ania@gmail.com	+48(501)116-747	\N	Заметка
4	28	Joanna Ratajczak	joanna.ratajczak@vp.pl	+48(606)317-553	\N	\N
11	7	Владислав Олегович Малюгин	\N	+370(606)62-923	\N	Заметка
16	9	Ирина Агеевна Назарова	\N	+48(451)668-441	\N	Заметка
17	10	Ирина Леонардовна Мазуркевич	mazurkevich.irene@gmail.com	+375(29)587-23-50	\N	Заметка
18	5	Людмила Ивановна Лешевская	lus-75@yandex.ru	+48(517)518-738	\N	Заметка
20	8	Николай Олегович Федорчук	Fedorczuk16@gmail.com	+48(574)467-568	\N	Заметка
21	1	Павел Викторович Долгов	dalhoupavel@gmail.com	+48(796)329-765	\N	Заметка
24	15	Татьяна Ивановна Палачанская	tanya578@yandex.ru	+48(452)487-011	\N	Заметка
26	32	Элиза Романовна Синкевич	sinkevicheliza@gmail.com	+48(796)168-445	\N	Заметка
28	42	Elżbieta Łobodzińska	\N		\N	Notatka
29	43	Анна Чернолуцкая	anula.chernolutska@gmail.com		\N	Notatka
1	37	Agnieszka Kowaliw	a_kowaliw@poczta.fm		\N	Заметка
3	36	Danuta Szuwarowska	\N		\N	Заметка
5	38	Kamila Lipowska	\N		\N	Заметка
6	39	Olga Chrzanowiecka	chrzanowieckaolga@gmail.com		\N	Заметка
7	31	Александра Сергеевна Воронько	Ola.varanko@gmail.com		\N	Заметка
8	30	Александра Сергеевна Гринкевич	grinkevichaleksandra102@gmail.com		\N	Заметка
9	41	Алина	\N		\N	Заметка
10	34	Анастасия	\N		\N	Заметка
12	18	Дарья Витальевна Мелешкина	mialeshkinadarya@gmail.com		\N	Заметка
13	20	Екатерина Владимировна Маковская	katerina.makowskaya@gmail.com		\N	\N
14	33	Елена	\N		\N	Заметка
15	26	Игорь Алексеевич Дабралет	igardabralet@gmail.com		\N	Заметка
19	29	Никита Феликсович Радецкий	nikitorrro@gmail.com		\N	Заметка
22	22	Сергей  Геннадьевич Крыжевич	\N		\N	Заметка
23	19	Сергей Александрович Наумов	sergei.naumoff@gmail.com		\N	Заметка
25	12	Тест Тест	\N		\N	Заметка
27	35	Янина Александровна Лебедко	\N		\N	Заметка
\.


--
-- Data for Name: telegram_sessions; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.telegram_sessions (id, "phoneNumber", "sessionString", "createdAt", "updatedAt") FROM stdin;
1	+573169932598	1AQAOMTQ5LjE1NC4xNzUuNTMBu8A4yEcq+QD0//SCPMPhZnGwf5rn4IIDQr5nlkeDMDnfeuGTJDJxRWxtOQg8VODPNcLQc7AZ5XbK0vblhY5lgfjCijFUfxBqEcgbINXfO4FwJnTmlXnavPX9+OO3gAnwzaZpdLopGoyM7Xk23YQrcl1IkihQlNAzNAMrp5cKAXcMQ/CjmE0FvuE2BTtKfL+R18FLEBriyEBES6Zbji3ihUenWqWMfoCEhJY+TyGDvitSH6a1/g/07V+7MOnqtWCqhsLgU8T32fX2SorsZVyqY1FECL0AMt+ElHsCuH7a9YA6LuEslg4EuQKOaObKwcazmWnCXOaTQxTIeKVp2coetP8=	2026-04-08 10:28:51.715	2026-04-08 10:28:51.715
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."user" (id, email, name, "emailVerified", image, "createdAt", "updatedAt", alfa_email, alfa_token, role, tg_chat_id, teacher_id) FROM stdin;
7e24d9e3-417b-44bc-9057-6d4e2ec76e5f	ya.vasileuskaya@gmail.com	Яна	t	\N	2026-03-21 10:13:05.335	2026-03-21 10:13:05.335	\N	\N	ADMIN	\N	\N
NidgoSqisHPx84WQ2VzKu3UgClh5ROhM	admin@btw.com	Główny Admin	f	\N	2026-03-17 17:58:59.145	2026-03-17 17:58:59.145	ya.vasileuskaya@gmail.com	1817b05f-d8f0-11ef-b9b8-3cecefbdd1ae	ADMIN	45556580	\N
Rbtt2FczkAAL1VZZOvtJca68s9hXbqiR	u.kamisarau@gmail.com	Uladzislau Kamisarau	f	\N	2026-03-18 21:42:01.495	2026-03-18 21:42:01.495	\N	\N	TEACHER	455565802	21
\.


--
-- Data for Name: verification; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.verification (id, identifier, value, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: ReportCriterion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."ReportCriterion_id_seq"', 2, true);


--
-- Name: ReportCycle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."ReportCycle_id_seq"', 17, true);


--
-- Name: StudentReport_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."StudentReport_id_seq"', 1483, true);


--
-- Name: alfaSubjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."alfaSubjects_id_seq"', 20, true);


--
-- Name: alfa_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.alfa_settings_id_seq', 1, false);


--
-- Name: billing_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.billing_logs_id_seq', 32, true);


--
-- Name: billing_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.billing_templates_id_seq', 1, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.categories_id_seq', 2, true);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.customers_id_seq', 1286, true);


--
-- Name: message_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.message_logs_id_seq', 15, true);


--
-- Name: snippets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.snippets_id_seq', 3, true);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.subjects_id_seq', 1, true);


--
-- Name: teacher_working_hours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.teacher_working_hours_id_seq', 1, true);


--
-- Name: teachers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.teachers_id_seq', 29, true);


--
-- Name: ReportCriterion ReportCriterion_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportCriterion"
    ADD CONSTRAINT "ReportCriterion_pkey" PRIMARY KEY (id);


--
-- Name: ReportCycle ReportCycle_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportCycle"
    ADD CONSTRAINT "ReportCycle_pkey" PRIMARY KEY (id);


--
-- Name: ReportSettings ReportSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportSettings"
    ADD CONSTRAINT "ReportSettings_pkey" PRIMARY KEY (id);


--
-- Name: ReportTemplate ReportTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportTemplate"
    ADD CONSTRAINT "ReportTemplate_pkey" PRIMARY KEY (id);


--
-- Name: StudentReport StudentReport_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentReport"
    ADD CONSTRAINT "StudentReport_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: account account_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT account_pkey PRIMARY KEY (id);


--
-- Name: alfaSubjects alfaSubjects_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."alfaSubjects"
    ADD CONSTRAINT "alfaSubjects_pkey" PRIMARY KEY (id);


--
-- Name: alfa_settings alfa_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.alfa_settings
    ADD CONSTRAINT alfa_settings_pkey PRIMARY KEY (id);


--
-- Name: billing_logs billing_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billing_logs
    ADD CONSTRAINT billing_logs_pkey PRIMARY KEY (id);


--
-- Name: billing_templates billing_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billing_templates
    ADD CONSTRAINT billing_templates_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: message_logs message_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (id);


--
-- Name: snippets snippets_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.snippets
    ADD CONSTRAINT snippets_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: sync_states sync_states_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.sync_states
    ADD CONSTRAINT sync_states_pkey PRIMARY KEY (type);


--
-- Name: teacher_subjects teacher_subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT teacher_subjects_pkey PRIMARY KEY ("teacherId", "subjectId");


--
-- Name: teacher_working_hours teacher_working_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teacher_working_hours
    ADD CONSTRAINT teacher_working_hours_pkey PRIMARY KEY (id);


--
-- Name: teachers teachers_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teachers
    ADD CONSTRAINT teachers_pkey PRIMARY KEY (id);


--
-- Name: telegram_sessions telegram_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.telegram_sessions
    ADD CONSTRAINT telegram_sessions_pkey PRIMARY KEY (id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: verification verification_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.verification
    ADD CONSTRAINT verification_pkey PRIMARY KEY (id);


--
-- Name: StudentReport_cycleId_idx; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "StudentReport_cycleId_idx" ON public."StudentReport" USING btree ("cycleId");


--
-- Name: StudentReport_status_idx; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "StudentReport_status_idx" ON public."StudentReport" USING btree (status);


--
-- Name: StudentReport_teacherId_idx; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX "StudentReport_teacherId_idx" ON public."StudentReport" USING btree ("teacherId");


--
-- Name: alfaSubjects_alfa_id_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "alfaSubjects_alfa_id_key" ON public."alfaSubjects" USING btree (alfa_id);


--
-- Name: customers_alfa_id_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX customers_alfa_id_key ON public.customers USING btree (alfa_id);


--
-- Name: message_logs_alfa_id_idx; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX message_logs_alfa_id_idx ON public.message_logs USING btree (alfa_id);


--
-- Name: session_token_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX session_token_key ON public.session USING btree (token);


--
-- Name: teachers_alfacrmId_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX "teachers_alfacrmId_key" ON public.teachers USING btree ("alfacrmId");


--
-- Name: user_alfa_email_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX user_alfa_email_key ON public."user" USING btree (alfa_email);


--
-- Name: user_email_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX user_email_key ON public."user" USING btree (email);


--
-- Name: user_tg_chat_id_key; Type: INDEX; Schema: public; Owner: root
--

CREATE UNIQUE INDEX user_tg_chat_id_key ON public."user" USING btree (tg_chat_id);


--
-- Name: ReportCriterion ReportCriterion_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ReportCriterion"
    ADD CONSTRAINT "ReportCriterion_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public."ReportTemplate"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StudentReport StudentReport_cycleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentReport"
    ADD CONSTRAINT "StudentReport_cycleId_fkey" FOREIGN KEY ("cycleId") REFERENCES public."ReportCycle"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StudentReport StudentReport_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentReport"
    ADD CONSTRAINT "StudentReport_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public.customers(alfa_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StudentReport StudentReport_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."StudentReport"
    ADD CONSTRAINT "StudentReport_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public.teachers("alfacrmId") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: account account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.account
    ADD CONSTRAINT "account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: billing_logs billing_logs_alfa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.billing_logs
    ADD CONSTRAINT billing_logs_alfa_id_fkey FOREIGN KEY (alfa_id) REFERENCES public.customers(alfa_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: categories categories_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT "categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: message_logs message_logs_alfa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.message_logs
    ADD CONSTRAINT message_logs_alfa_id_fkey FOREIGN KEY (alfa_id) REFERENCES public.customers(alfa_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: session session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT "session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."user"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: snippets snippets_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.snippets
    ADD CONSTRAINT "snippets_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teacher_subjects teacher_subjects_subjectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT "teacher_subjects_subjectId_fkey" FOREIGN KEY ("subjectId") REFERENCES public.subjects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teacher_subjects teacher_subjects_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teacher_subjects
    ADD CONSTRAINT "teacher_subjects_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public.teachers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: teacher_working_hours teacher_working_hours_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.teacher_working_hours
    ADD CONSTRAINT "teacher_working_hours_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public.teachers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user user_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_teacher_id_fkey FOREIGN KEY (teacher_id) REFERENCES public.teachers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict Ru308amwoGaDsJwKCuiiJtuuXHN8jDiCI8avdQLxClnXCqmhFSDCQWZlpzYZmVn

